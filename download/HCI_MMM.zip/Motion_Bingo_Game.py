import pygame
##from changeColor import playGame
from pykinect2 import PyKinectV2
from pykinect2.PyKinectV2 import *
from pykinect2 import PyKinectRuntime
import time

import ctypes
import _ctypes
import pygame
import sys

import random
import math
import datetime



size = 1000,500
screen = pygame.display.set_mode(size)
starttime = 0
starttime2 = 0

buttonlist= [0,0,0,0,0,0,0,0,0]


if sys.hexversion >= 0x03000000:
    import _thread as thread
else:
    import thread

# colors for drawing different bodies 
SKELETON_COLORS = [pygame.color.THECOLORS["red"],
                  pygame.color.THECOLORS["blue"],
                  pygame.color.THECOLORS["green"],
                  pygame.color.THECOLORS["orange"],
                  pygame.color.THECOLORS["purple"],
                  pygame.color.THECOLORS["yellow"],
                  pygame.color.THECOLORS["violet"]]

colours = {"White" : (255, 255, 255), "Black" : (0,0,0), "Red" : (255,0,0), "Blue" : (0,0,255), "Green":(0, 204, 0),
           "Cyan": (0, 255, 255)}
WHITE = (255, 255, 255)
BLACK = (0,0,0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BRIGHTBLUE = (0, 50, 255)
DARKURQUOISE = (3, 54, 73)
GREEN = (0, 204, 0)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)

#############################
class Screen:
    def __init__(self, title, width=1400, height=800, fill=YELLOW):
        self.title = title
        self.width = width
        self.height = height
        self.fill = fill
        self.current = False


    def makeCurrent(self):
        pygame.display.set_caption(self.title)
        self.current = True
        self.screen = pygame.display.set_mode((self.width, self.height),pygame.RESIZABLE)


    def endCurrent(self):
        self.current = False


    def checkUpdate(self):
        return self.current


    def screenUpdate(self):
        if(self.current):
            self.screen.fill(self.fill)


    def returnTitle(self):
        return self.screen

    def show_middle_img(self):
        middle_img = pygame.image.load("middle.png")
        middle_img = pygame.transform.scale(middle_img, (500, 100))
        #middle_img.moveTo(100,100)
        screen.blit(middle_img, (500, 50))

    def show_left_img(self):
        left_img = pygame.image.load("left.png")
        left_img = pygame.transform.scale(left_img, (450, 200))
        #left_img.moveTo(100, 300)
        screen.blit(left_img, (150, 300))

    def show_return_img(self):
        return_img = pygame.image.load("ReturnPage.png")
        return_img = pygame.transform.scale(return_img, (1600, 800))
        #left_img.moveTo(100, 300)
        screen.blit(return_img, (0, 0))

class Button:
    def __init__(self, x, y, sx, sy, bborder,bcolour, fbcolour, font, fontsize, fcolour, text):
        self.x = x
        self.y = y
        self.sx = sx
        self.sy = sy
        self.bborder = bborder
        self.bcolour = bcolour
        self.fbcolour = fbcolour
        self.fcolour = fcolour
        self.fontsize = fontsize
        self.text = text
        self.current = False
        self.buttonf = pygame.font.SysFont(font, fontsize)


    def showButton(self, display, correct):
        if correct ==0:
            if(self.current):
                pygame.draw.rect(display, self.fbcolour, (self.x, self.y, self.sx, self.sy))
            else:
                pygame.draw.rect(display, self.bcolour, (self.x, self.y, self.sx, self.sy),self.bborder)
            textsurface = self.buttonf.render(self.text, False, self.fcolour)
            display.blit(textsurface, ((self.x + (self.sx/2) - (self.fontsize/2)*(len(self.text)/2)-5,(self.y + (self.sy/2) - (self.fontsize/2) - 4))))

        elif correct == 1:            
            circle_img = pygame.image.load("circle.png")
            circle_img = pygame.transform.scale(circle_img, (self.sx, self.sy))

            screen.blit(circle_img, (self.x, self.y))
            


    def focusCheck(self, mousepos, mouseclick):
        if(mousepos[0] >= self.x and mousepos[0] <= self.x + self.sx and mousepos[1] >= self.y and mousepos[1] <= self.y + self.sy):
            self.current = True
            return mouseclick[0]
        else:
            self.current = False
            return False
###########################


def show_correct_img():
        c_img = pygame.image.load("4.png")
        c_img = pygame.transform.scale(c_img, (1600, 1000))

        screen.blit(c_img, (0, 0))
        pygame.display.update()

def show_incorrect_img():
        c_img = pygame.image.load("5.png")
        c_img = pygame.transform.scale(c_img, (1600, 1000))

        screen.blit(c_img, (0, 0))
        pygame.display.update()
        
        
class PyKinectCollect(object):
    def __init__(self, title, width = 1400, height=800, fill=YELLOW):
        #pygame.init()
#        pygame.font.init()

        # Used to manage how fast the screen updates
        self._clock = pygame.time.Clock()

        # Set the width and height of the screen [width, height]
        self._infoObject = pygame.display.Info()
        self._screen = pygame.display.set_mode((self._infoObject.current_w >> 1, self._infoObject.current_h >> 1), 
                                               pygame.HWSURFACE|pygame.DOUBLEBUF|pygame.RESIZABLE)

        #pygame.display.set_caption("Bingo Game for Etiquette")

        # Loop until the user clicks the close button.
        self._done = False

        # Kinect runtime object, we want only color and body frames 
        self._kinect = PyKinectRuntime.PyKinectRuntime(PyKinectV2.FrameSourceTypes_Color | PyKinectV2.FrameSourceTypes_Body)

        # back buffer surface for getting Kinect color frames, 32bit color, width and height equal to the Kinect color frame size
        self._frame_surface = pygame.Surface((self._kinect.color_frame_desc.Width, self._kinect.color_frame_desc.Height), 0, 32)

        # here we will store skeleton data 
        self._bodies = None

        # List of ball sprite, managed by a class called Group
        # This also holds all the objects that the player can collide with
        self.ballList1 = pygame.sprite.Group()
        self.ballList2 = pygame.sprite.Group()

        self.current = False
        self.title = title
        self.width = width
        self.height = height
        self.fill = fill
        
        
    def makeCurrent(self):
        pygame.display.set_caption(self.title)
        self.current = True
        self.screen = pygame.display.set_mode()

        
    def endCurrent(self):
        self.current = False
        


    def checkUpdate(self):
        return self.current


    def screenUpdate(self):
        if(self.current):
            self.screen.fill(self.fill)

    def returnTitle(self):
        return self.screen

            
    def draw_body_bone(self, joints, jointPoints, color, joint0, joint1, boardN):
        joint0State = joints[joint0].TrackingState;
        joint1State = joints[joint1].TrackingState;

        # both joints are not tracked
        if (joint0State == PyKinectV2.TrackingState_NotTracked) or (joint1State == PyKinectV2.TrackingState_NotTracked):
            return

        # both joints are not *really* tracked
        if (joint0State == PyKinectV2.TrackingState_Inferred) and (joint1State == PyKinectV2.TrackingState_Inferred):
            return

        start = (0, 0)
        end = (0, 0)
        global starttime
        global flag
        

        if (boardN ==1):
            
            JointX = jointPoints[PyKinectV2.JointType_Head].x
            JointY = jointPoints[PyKinectV2.JointType_Head].y
            
            
            if (1400 <= JointX) and (1000 >= JointY):
                
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('right', fts2)
                    if (starttime+2 < fts2):
                        print('touch1')
                        flag = 0

                        
            elif (700 >= JointX) and (1000 >= JointY):
                
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('left', fts2)
                    if (starttime+2 < fts2):
                        print('touch1')
                        flag = 2
                        
                        
            else:
                starttime = 0



        elif (boardN ==2):
            JointX = jointPoints[PyKinectV2.JointType_Head].x
            JointY = jointPoints[PyKinectV2.JointType_Head].y
            
           
            
            if (1400 <= JointX) and (50 <= JointY) and (250 >= JointY):
                
                print('touch2 left')
                flag = 2

            elif (700 >= JointX) and (50 <= JointY) and (250 >= JointY):
                print('touch2 right')
                flag = 0



        elif (boardN ==3):
            JointXR = jointPoints[PyKinectV2.JointType_HandRight].x
            JointYR = jointPoints[PyKinectV2.JointType_HandRight].y
            
           
            
            JointXL = jointPoints[PyKinectV2.JointType_HandLeft].x
            JointYL = jointPoints[PyKinectV2.JointType_HandLeft].y
            
            
            if (1400 <= JointXR) and (1000 >= JointYR):
                
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('HandRight', fts2)
                    if (starttime+2 < fts2):
                        print('touch3')
                        flag = 0
                        
                        
            elif(700 >= JointXL) and (1000 >= JointYL):
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('HandLeft', fts2)
                    if (starttime+2 < fts2):
                        print('touch3')
                        flag = 2
            else:
                starttime = 0


        elif (boardN ==5):
            JointXR = jointPoints[PyKinectV2.JointType_AnkleRight].x
            JointYR = jointPoints[PyKinectV2.JointType_AnkleRight].y
            
           
            
            JointXL = jointPoints[PyKinectV2.JointType_AnkleLeft].x
            JointYL = jointPoints[PyKinectV2.JointType_AnkleLeft].y
            
            
            if (850 >= JointXL) and (900 <= JointYL) and (1200 >= JointYL):
                
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('AnkleRight', fts2)
                    if (starttime+1 < fts2):
                        print('touch3')
                        flag = 0
                        
                        
            elif(1200 <= JointXR) and (1000 <= JointYR):
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('AnkleLeft', fts2)
                    if (starttime+1 < fts2):
                        print('touch3')
                        flag = 2
            else:
                starttime = 0

        elif (boardN ==9):
            JointXR = jointPoints[PyKinectV2.JointType_ElbowRight].x
            JointYR = jointPoints[PyKinectV2.JointType_ElbowRight].y
            
           
            
            JointXL = jointPoints[PyKinectV2.JointType_ElbowLeft].x
            JointYL = jointPoints[PyKinectV2.JointType_ElbowLeft].y
            
            
            if (1450 <= JointXR):
                
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('ElbowRight', fts2)
                    if (starttime+1 < fts2):
                        print('touch3')
                        flag = 0
                        
                        
            elif(600 >= JointXL):
                if (starttime == 0):
                    timestamp = datetime.datetime.now().timestamp()
                    fts = timestamp
                    starttime = fts
                    print('time start!!!!!!!!!!!!!!!!!!!!!!!!!')
                    pygame.display.update()
                    print (starttime)
                    

                else:
                    timestamp = datetime.datetime.now().timestamp()
                    fts2 = timestamp
                    print('ElbowLeft', fts2)
                    if (starttime+1 < fts2):
                        print('touch3')
                        flag = 2
            else:
                starttime = 0
                        
                        
        
        
            
                    
 
    def draw_body(self, joints, jointPoints, color,boardN):
        # Torso
        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_Head, PyKinectV2.JointType_Neck,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_Neck, PyKinectV2.JointType_SpineShoulder,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineShoulder, PyKinectV2.JointType_SpineMid,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineMid, PyKinectV2.JointType_SpineBase,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineShoulder, PyKinectV2.JointType_ShoulderRight,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineShoulder, PyKinectV2.JointType_ShoulderLeft,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineBase, PyKinectV2.JointType_HipRight,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_SpineBase, PyKinectV2.JointType_HipLeft,boardN);
    
##        # Right Arm    
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_ShoulderRight, PyKinectV2.JointType_ElbowRight);
        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_ElbowRight, PyKinectV2.JointType_WristRight, boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_WristRight, PyKinectV2.JointType_HandRight);
        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_HandRight, PyKinectV2.JointType_HandTipRight,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_WristRight, PyKinectV2.JointType_ThumbRight);
##
##        # Left Arm
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_ShoulderLeft, PyKinectV2.JointType_ElbowLeft);
        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_ElbowLeft, PyKinectV2.JointType_WristLeft,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_WristLeft, PyKinectV2.JointType_HandLeft);
        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_HandLeft, PyKinectV2.JointType_HandTipLeft,boardN);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_WristLeft, PyKinectV2.JointType_ThumbLeft);
##
##        # Right Leg
#        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_HipRight, PyKinectV2.JointType_KneeRight);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_KneeRight, PyKinectV2.JointType_AnkleRight);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_AnkleRight, PyKinectV2.JointType_FootRight);
##
##        # Left Leg
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_HipLeft, PyKinectV2.JointType_KneeLeft);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_KneeLeft, PyKinectV2.JointType_AnkleLeft);
##        self.draw_body_bone(joints, jointPoints, color, PyKinectV2.JointType_AnkleLeft, PyKinectV2.JointType_FootLeft);


    def draw_color_frame(self, frame, target_surface):
        target_surface.lock()
        address = self._kinect.surface_as_array(target_surface.get_buffer())
        ctypes.memmove(address, frame.ctypes.data, frame.size)
        del address
        target_surface.unlock()
            
    
    def playGame(self,boardN):
        global flag
        flag =1
        #self.spawnObjects()
        # -------- Main Program Loop -----------
        while not self._done:
            # --- Main event loop
            for event in pygame.event.get(): # User did something
                if event.type == pygame.QUIT: # If user clicked close
                    self._done = True # Flag that we are done so we exit this loop

                elif event.type == pygame.VIDEORESIZE: # window resized
                    self._screen = pygame.display.set_mode(event.dict['size'], 
                                               pygame.HWSURFACE|pygame.DOUBLEBUF|pygame.RESIZABLE)
                    
            # --- Game logic should go here

            # --- Getting frames and drawing  
            # --- Woohoo! We've got a color frame! Let's fill out back buffer surface with frame's data 
            if self._kinect.has_new_color_frame():
                frame = self._kinect.get_last_color_frame()
                self.draw_color_frame(frame, self._frame_surface)
                frame = None

            # --- Cool! We have a body frame, so can get skeletons
            if self._kinect.has_new_body_frame(): 
                self._bodies = self._kinect.get_last_body_frame()

            # --- draw skeletons to _frame_surface
            if self._bodies is not None: 
                for i in range(0, self._kinect.max_body_count):
                    body = self._bodies.bodies[i]
                    if body.is_tracked and flag==1:
                        joints = body.joints 
                        # convert joint coordinates to color space 
                        joint_points = self._kinect.body_joints_to_color_space(joints)
                        self.draw_body(joints, joint_points, SKELETON_COLORS[i],boardN)
                    elif (flag == 0) or (flag ==2):
                        break
##                    show_correct_img()
##                    print("0")

            if (flag == 0) or (flag == 2):
                
                break

            



            # --- copy back buffer surface pixels to the screen, resize it if needed and keep aspect ratio
            # --- (screen size may be different from Kinect's color frame size)
            h_to_w = float(self._frame_surface.get_height()) / self._frame_surface.get_width()
            target_height = int(h_to_w * self._screen.get_width())
            surface_to_draw = pygame.transform.scale(self._frame_surface, (self._screen.get_width(), target_height));
            self._screen.blit(surface_to_draw, (0,0))
            surface_to_draw = None
#            pygame.display.update()

            titleImg = str(boardN) +"-3.png"
            OptionImg1 = str(boardN)+ "-1.png"
            OptionImg2 = str(boardN )+"-2.png"
            
            img = pygame.image.load(OptionImg1)
            img = pygame.transform.scale(img, (250, 200))
            #img = pygame.transform.rotate(img, 180)

            img2 = pygame.image.load(OptionImg2)
            img2 = pygame.transform.scale(img2, (250, 200))
            #img2 = pygame.transform.rotate(img2, 180)

            img3 = pygame.image.load(titleImg)
            img3 = pygame.transform.scale(img3, (1000, 140))
            #img = pygame.transform.rotate(img, 180)

            screen.blit(img, (250, 170))
            screen.blit(img2, (1050, 170))
            screen.blit(img3, (270, 10))

            pygame.display.update()
              

            
            # --- Go ahead and update the screen with what we've drawn.
            pygame.display.flip()

            # --- Limit to 60 frames per second
            self._clock.tick(60)

        if flag == 0:
        #show_incorrect_img()
            global buttonlist
            buttonlist[boardN-1]=1
            
            show_correct_img()
            print("0")
        elif flag ==2:
            show_incorrect_img()
            print('2')
        # Close our Kinect sensor, close the window and quit.
        #self._kinect.close()
        #sys.exit()

        pygame.time.delay(3000)

##        pygame.init()
##        pygame.font.init()
##        w_game()

   

####################   ↑↑↑ Kinect Game    ##############################################
        
##


#__main__ = "Kinect v2 Python Game"

def w_game():
    pygame.font.init()

    game = PyKinectCollect("Bingo Game for Etiquette")
    b_screen = Screen("Bingo_Screen")


    #g_screen=game.playGame()

    win = b_screen.makeCurrent()

    done = False

    ####Button 그리기
    returnButton = Button(1000, 650, 300, 100,3, colours["Black"], colours["Cyan"], "arial", 20, colours["Black"], "RETURN")
    bingo_1 = Button(800,200,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "1")
    bingo_2 = Button(950,200,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "2")
    bingo_3 = Button(1100,200,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "3")
    bingo_4 = Button(800,350,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "4")
    bingo_5 = Button(950,350,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "5")
    bingo_6 = Button(1100,350,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "6")
    bingo_7 = Button(800,500,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "7")
    bingo_8 = Button(950,500,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "8")
    bingo_9 = Button(1100,500,150,150,3, colours["White"], colours["Cyan"],"arial", 20, colours["Black"], "9")


    toggle = False

    while not done:
        b_screen.screenUpdate()
        b_screen.show_middle_img()
        b_screen.show_left_img()
        game.screenUpdate()
        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()
        keys = pygame.key.get_pressed()
        
    #############b_1  
        if b_screen.checkUpdate():
            screen2button = bingo_1.focusCheck(mouse_pos, mouse_click)
            bingo_1.showButton(b_screen.returnTitle(),buttonlist[0])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(1)
                b_screen.endCurrent()

        elif game.checkUpdate():
            b_screen.show_return_img()
            returnm = returnButton.focusCheck(mouse_pos, mouse_click)
            returnButton.showButton(game.returnTitle(),0)
            
            if returnm:
                win = b_screen.makeCurrent()
                
                game.endCurrent()
                

    #############b_2  
        if b_screen.checkUpdate():
            screen2button = bingo_2.focusCheck(mouse_pos, mouse_click)
            bingo_2.showButton(b_screen.returnTitle(),buttonlist[1])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(2)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_3  
        if b_screen.checkUpdate():
            screen2button = bingo_3.focusCheck(mouse_pos, mouse_click)
            bingo_3.showButton(b_screen.returnTitle(),buttonlist[2])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(3)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_4  
        if b_screen.checkUpdate():
            screen2button = bingo_4.focusCheck(mouse_pos, mouse_click)
            bingo_4.showButton(b_screen.returnTitle(),buttonlist[3])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(4)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_5  
        if b_screen.checkUpdate():
            screen2button = bingo_5.focusCheck(mouse_pos, mouse_click)
            bingo_5.showButton(b_screen.returnTitle(),buttonlist[4])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(5)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_6 
        if b_screen.checkUpdate():
            screen2button = bingo_6.focusCheck(mouse_pos, mouse_click)
            bingo_6.showButton(b_screen.returnTitle(),buttonlist[5])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(6)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_7  
        if b_screen.checkUpdate():
            screen2button = bingo_7.focusCheck(mouse_pos, mouse_click)
            bingo_7.showButton(b_screen.returnTitle(),buttonlist[6])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(7)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_8  
        if b_screen.checkUpdate():
            screen2button = bingo_8.focusCheck(mouse_pos, mouse_click)
            bingo_8.showButton(b_screen.returnTitle(),buttonlist[7])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(8)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()
    #############b_9  
        if b_screen.checkUpdate():
            screen2button = bingo_9.focusCheck(mouse_pos, mouse_click)
            bingo_9.showButton(b_screen.returnTitle(),buttonlist[8])
            if screen2button:
                win = game.makeCurrent()
                g_screen=game.playGame(9)
                b_screen.endCurrent()

    ##    elif g_screen.checkUpdate():
    ##        returnm = returnButton.focusCheck(mouse_pos, mouse_click)
    ##        returnButton.showButton(screen2.returnTitle())
    ##
    ##        if returnm:
    ##            win = menuScreen.makeCurrent()
    ##            screen2.endCurrent()















        for event in pygame.event.get():
            if(event.type == pygame.QUIT):
                done = True
        for event in pygame.event.get():
            if(event.type == pygame.QUIT):
                done = True

        pygame.display.update()

    pygame.quit()
flag =1
w_game()
